/*
 *
 *It is a user interactive code Program and class to represent a bank account,
 *where following details can be maintained: Depositor name, account
 *number type of account, balance amount in the account.
 *Also, the following
 *set of operations/actions should be provided: assign initial balance, deposit an amount, withdraw amount(make sure
 *you check the balance), and display name & balance on demand
 *
 *
 *Owner : Shri Hari
 *Date  : 26 oct 2021
 *
 */

#include <iostream>
#include <cstring>
#include <limits.h>
#include <math.h>
#include <cstdlib>
#include <iomanip>
#include <fstream>
using namespace std;

// Maximum amount of Customer Data that can be entered at one time
#define size 40

// Forward Declaration of a Class  Bank Employee

class Bank
{
protected:
    // all information
    long int accountNo_;
    char *name_;
    char *accountType_;
    char *address_;
    double bal;
    int password_;

    // For make count Register
    static int counter;
    int registerNo;

    // For Account Number
    static int counterAccNO;

public:
    Bank()
    {
        accountNo_ = counterAccNO;
        counterAccNO++;

        name_ = NULL;
        accountType_ = NULL;
        address_ = NULL;
        bal = 0.0;
        password_ = 0;

        registerNo = counter;
        counter++;
    }
};

// Bank Customer Class
class BankCustomer : public Bank
{

public:
    BankCustomer()
    {
        accountNo_ = counterAccNO;
        counterAccNO++;

        name_ = NULL;
        accountType_ = NULL;
        address_ = NULL;
        bal = 0.0;
        password_ = 0;

        registerNo = counter;
        counter++;
    }
    //  It Takes data from the user
    void feedData();

    // For depositing the amount and printing net balance
    void deposit();

    // For withdraw of  the amount and printing net balance
    void withdraw();

    // Display Account Number
    void accDisplay();

    // It display the data in console
    void display();

    // void Dispaly all customer bank account no and name
    void displayAccName();

    // Delete the existing Customer
    void deleteCustomer();

    // Print record number  account number related to an account holder Emergency only when customer forgot the user name and password)
    friend void displayRecordNo(BankCustomer B[], size_t i);

    // It display the data for Customer in file
    friend void display_Customer(BankCustomer B[], size_t i);

    // It display the data for Employee in file
    friend void display_Employee(BankCustomer B[], size_t i);

    // friend function to find Customer as they are valid or not (Password)
    // it is used to  print all customer data
    friend void findCustomer(BankCustomer BCus[], size_t i);
};
// For static variable for register no
int Bank::counter = 1;

// For Account Number
int Bank::counterAccNO = 10000000;

//  It Takes data from the user feed into it
void BankCustomer::feedData()
{
    char ch[20], ch2[10];
    char address[20];

    cout << "\n Enter Details: \n";
    cout << "-----------------------" << endl;

    cin.ignore();
    cout << "Enter the name of the persons (UserName is same as name)" << endl;
    cin.getline(ch, 20);
    name_ = new char[strlen(ch) + 1];
    strcpy(name_, ch);

    cout << "\nAccount Type : "
         << "Savings\tor\t"
         << "Current Account" << endl;
    cin.ignore();
    cin.getline(ch2, 10);
    accountType_ = new char[strlen(ch2) + 1];
    strcpy(accountType_, ch);

    cout << "Enter the Address of the persons: " << name_ << endl;
    cin.ignore();
    cin.getline(address, 20);
    address_ = new char[strlen(address) + 1];
    strcpy(address_, address);

    cout << " Enter the Balance : " << endl;
    cin >> bal;

    cout << "Make a strong password for the current user (4 digit)" << name_ << endl;
    cin >> password_;
}

// void Dispaly all customer bank account no and name
void BankCustomer::displayAccName()
{
    cout.setf(ios::left, ios::adjustfield);
    cout << "Register No(Sl. No.)\t";
    cout << "Name";
    cout << "\t\t";
    cout << "ACCOUNT NO.";
    cout << "\t\t";
    cout << "Balance";
    cout << endl;

    cout << this->registerNo;
    cout << "\t\t\t";
    cout << this->name_;
    cout << "\t\t";
    cout << this->accountNo_;
    cout << "\t\t";
    cout << this->bal;
    cout << endl;

    return;
}

void BankCustomer::deposit() // depositing an amount
{
    double damt1;
    cout << "\n Enter Deposit Amount = ";
    cin >> damt1;
    this->bal += damt1;
    return;
}

void BankCustomer::withdraw() // withdrawing an amount
{
    double wamt1;
    cout << "\nEnter Withdraw Amount : " << endl;
    cin >> wamt1;
    if (wamt1 > bal)
        cout << "\nCannot Withdraw Amount" << endl;
    this->bal = -wamt1;
    return;
}

void BankCustomer::display() // displaying the details
{
    cout << "----------------------" << endl;
    cout.setf(ios::left, ios::adjustfield);
    cout << "Register No(Sl. No.)\t ";
    cout << "Name";
    cout << "\t ";
    cout << "ACCOUNT NO.";
    cout << "\t ";
    cout << "Account Type";
    cout << "\t";
    cout << "Balance ";
    cout << "\t";
    cout << "Address ";
    cout << endl;

    // Printing
    cout << this->registerNo;
    cout << "\t\t";
    cout << this->name_;
    cout << "\t\t";
    cout << this->accountNo_;
    cout << "\t\t";
    cout << this->accountType_;
    cout << "\t\t";
    cout << this->bal;
    cout << "\t\t";
    cout << this->address_;
    cout << endl;
}

// It display the data for Employee in file
void display_Employee(Bank B[], size_t i)
{

    ofstream fwrite("BankDataFile", ios::out);

    for (int customerCount = 0; customerCount < i; customerCount++)
    {
        fwrite.write((char *)&B[customerCount], sizeof(B[customerCount])); // write the object in binary format
    }
    fwrite.close();

    return;
}

// it create file  CustomerDataFile for storage
void display_Customer(BankCustomer B[], size_t i)
{

    ofstream fwrite("CustomerDataFile", ios::out);

    for (int customerCount = 0; customerCount < i; customerCount++)
    {
        fwrite.write((char *)&B[customerCount], sizeof(B[customerCount])); // write the object in binary format
    }
    fwrite.close();

    return;
}

// Print record number  account number related to an account holder Emergency only when customer forgot the user name and password)
void displayRecordNo(BankCustomer B[], size_t i)
{
    long int acc = 0;
    cout << "\nPlease Enter the Accout No. " << endl;
    cin >> acc;
    ifstream fread("CustomerDataFile");

    while (fread)
    {
        BankCustomer s;                    // the default object is created
        fread.read((char *)&s, sizeof(s)); // the information is being red from the file object wise
                                           // after reading from file the member function of the object is being called.
        cout << endl;
        if (s.accountNo_ == acc)
        {
            s.display();
            break;
        }
    }
    fread.close();
    display_Customer(B, i);
    return;
}

// For display account no display
void BankCustomer::accDisplay()
{
    cout.setf(ios::left, ios::adjustfield);
    cout.width(20);
    cout << "ACCOUNT NO.";
    cout.width(20);
    cout << endl;
    cout.width(20);
    cout << this->accountNo_;
    cout << endl;
    cout.width(20);
}

// Delete the existing Customer
void BankCustomer::deleteCustomer()
{
    delete this->name_;
    accountNo_ = 0;
    name_ = NULL;
    accountType_ = NULL;
    address_ = NULL;
    bal = 0.0;
    password_ = 0;
    return;
}

// Customer Specific
void findCustomer(BankCustomer BCus[], size_t i)
{
    if (i > 0)
    {
        int pass{0}, l_temp{0};
        bool flag = true;
        cout << "\nPlease Enter Details: \n";
        cout << "-----------------------" << endl;

        char ch4[20], ch3[10];
        cin.ignore();
        cout << "Enter the UserName " << endl;
        cin.getline(ch4, 20);

        size_t choice{0}, i{0}, prev{0};
        cout << "Please enter 4 digit your Password" << endl;
        cin >> pass;

        ifstream fread("CustomerDataFile");

        while (fread)
        {
            BankCustomer s;
            fread.read((char *)&s, sizeof(s));
            cout << endl;
            if ((strcmp(s.name_, ch4) == 0) && (s.password_ == pass))
            {
                l_temp = s.registerNo - 1;
                flag = true;
                while (1)
                {
                    cout << "\t*------------------------     Welcome     ---------------------------------*" << endl;
                    cout << s.name_ << endl;
                    cout << "\n\n\t\tMENU"
                         << "\n1. View the Balance of the account\n"
                         << "\n2. Deposit an amount\n"
                         << "\n3. Withdraw an amount\n"
                         << "\n4. View account summary (All details)\n"

                         << "\n6. EXIT From this page \n"
                         << "\n Please enter your choice" << endl;
                    cin >> choice;
                    switch (choice)
                    {
                    case 1:
                        cout << "Your Balance is: " << BCus[l_temp].bal << endl;
                        display_Customer(BCus, i);
                        break;
                    case 2:
                        BCus[l_temp].deposit();
                        display_Customer(BCus, i);
                        break;
                    case 3:
                        BCus[l_temp].withdraw();
                        display_Customer(BCus, i);
                        break;
                    case 4:
                        BCus[l_temp].display();
                        display_Customer(BCus, i);
                        break;
                    case 6:
                        cout << "\nThank You For using our Bank Service\n******************************************************" << endl;
                        exit(0);
                    default:
                        cout << "\nInvalid Choice Entered, Please Choose Carefully" << endl;
                        break;
                    }
                }
            }
            if (flag)
            {
                cout << "\nInvalid Choice Entered, Please Choose Carefully" << endl;
            }
        }
        fread.close();
        return;
    }

    else
    {
        cout << "No Entry in Bank Data, Please tell Bank Employee to make a entry" << endl;
        return;
    }
}

int main()
{
    size_t choice{0}, i{0}, prev{0};

    BankCustomer B[size];

    while (1)
    {

        cout << "\n*******************************************************************************************" << endl;
        cout << "\t*------------------------     Welcome     ---------------------------------*" << endl;
        cout << "\n\n\t\tMENU"
             << "\n1. Open a Bank Account for a new Customer\n"
             << "\n2. Display the account number of the last entry\n"
             << "\n3. See/Edit/Delete Information For an Exiting Customer\n"
             << "\n4. Display a list of all the account holders of the bank along with their account numbers and balance\n"
             << "\n5. Print record no. from account number  related to an account holder Emergency only when customer forgot the user name and password)\n"
             << "\n6. Delete data of the current customer\n"
             << "\n7. EXIT"
             << "\n Please enter your choice" << endl;
        cin >> choice;

        switch (choice)
        {
        case 1:
            B[i].feedData();
            prev = i;
            i++;
            display_Customer(B, i);
            break;
        case 2:
            B[prev].accDisplay();
            break;
        case 3:
            findCustomer(B, i);
            break;
        case 4:
            for (size_t t = 0; t < i; t++)
            {
                B[t].displayAccName();
            }
            break;
        case 5:
            displayRecordNo(B, i);
            break;
        case 6:
            // BCus[l_temp].deleteCustomer();
            // display_Customer(BCus, i);
            // cout << "DELETED" << endl;
            break;
        case 7:
            cout << "\nThank You For using our Bank Service\n******************************************************" << endl;
            exit(0);

        default:
            cout << "\nInvalid Choice Entered, Please Choose Carefully" << endl;
            break;
        }
    }

    return 0;
}